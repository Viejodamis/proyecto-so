// agente.c – Envío de solicitudes desde CSV y handshake confiable
// Compila: gcc -Wall -Wextra -o bin/agente src/agente.c

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <time.h>
#include <sys/types.h>

#define MAXLINE 512

static void uso(const char *p) {
    fprintf(stderr,
            "Uso: %s -s <NombreAgente> -a <archivoCSV> -p <fifoControlador>\n"
            "CSV: Apellido,hora,duracion  (una por línea)\n", p);
    exit(EXIT_FAILURE);
}

static void rstrip(char *s) {
    size_t n = strlen(s);
    while (n > 0 && (s[n-1] == '\n' || s[n-1] == '\r')) s[--n] = '\0';
}

static int ensure_fifo_exists(const char *path) {
    struct stat st;
    if (stat(path, &st) == -1) return -1;
    return S_ISFIFO(st.st_mode) ? 0 : -1;
}

int main(int argc, char **argv) {
    char nombre[64] = {0};
    char csvPath[256] = {0};
    char fifoCtrl[256] = {0};

    int opt;
    while ((opt = getopt(argc, argv, "s:a:p:")) != -1) {
        switch (opt) {
            case 's': strncpy(nombre, optarg, sizeof(nombre)-1); break;
            case 'a': strncpy(csvPath, optarg, sizeof(csvPath)-1); break;
            case 'p': strncpy(fifoCtrl, optarg, sizeof(fifoCtrl)-1); break;
            default: uso(argv[0]);
        }
    }
    if (nombre[0]=='\0' || csvPath[0]=='\0' || fifoCtrl[0]=='\0') uso(argv[0]);

    if (ensure_fifo_exists(fifoCtrl) == -1) {
        fprintf(stderr, "[AGENTE] FIFO del controlador '%s' no existe.\n", fifoCtrl);
        return EXIT_FAILURE;
    }

    // Pipe de respuesta exclusivo
    char pipeResp[256];
    snprintf(pipeResp, sizeof(pipeResp), "/tmp/pipe_%s_%d", nombre, getpid());
    unlink(pipeResp);
    if (mkfifo(pipeResp, 0666) == -1) {
        fprintf(stderr, "[AGENTE] Error creando pipeResp '%s': %s\n",
                pipeResp, strerror(errno));
        return EXIT_FAILURE;
    }

    int fdw = open(fifoCtrl, O_WRONLY);
    if (fdw == -1) {
        fprintf(stderr, "[AGENTE] No pude abrir FIFO del controlador '%s': %s\n",
                fifoCtrl, strerror(errno));
        unlink(pipeResp);
        return EXIT_FAILURE;
    }

    char hello[MAXLINE];
    int n = snprintf(hello, sizeof(hello), "HELLO,%s,%s\n", nombre, pipeResp);
    if (write(fdw, hello, (size_t)n) != n) {
        fprintf(stderr, "[AGENTE] Error enviando HELLO: %s\n", strerror(errno));
        close(fdw); unlink(pipeResp); return EXIT_FAILURE;
    }
    printf("[AGENTE %s] Registrado. pipeResp=%s\n", nombre, pipeResp);
    fflush(stdout);

    int fdr = open(pipeResp, O_RDONLY);
    if (fdr == -1) {
        fprintf(stderr, "[AGENTE] No pude abrir mi pipeResp para lectura: %s\n",
                strerror(errno));
        close(fdw); unlink(pipeResp); return EXIT_FAILURE;
    }
    char resp[MAXLINE];
    ssize_t r = read(fdr, resp, sizeof(resp)-1);
    if (r <= 0) {
        printf("[AGENTE %s] Timeout/EOF esperando HELLO_OK.\n", nombre);
        close(fdr); close(fdw); unlink(pipeResp); return EXIT_FAILURE;
    }
    resp[r] = '\0';
    rstrip(resp);
    int horaActual = -1;
    if (sscanf(resp, "HELLO_OK,%d", &horaActual) == 1) {
        printf("[AGENTE %s] Recibido HELLO_OK (horaActual=%d)\n", nombre, horaActual);
    } else {
        printf("[AGENTE %s] Respuesta desconocida: '%s'\n", nombre, resp);
    }
    close(fdr); // ya no necesitamos seguir leyendo

    FILE *fp = fopen(csvPath, "r");
    if (!fp) {
        fprintf(stderr, "[AGENTE] No pude abrir CSV '%s': %s\n", csvPath, strerror(errno));
        close(fdw); unlink(pipeResp); return EXIT_FAILURE;
    }

    char linea[MAXLINE];
    while (fgets(linea, sizeof(linea), fp)) {
        rstrip(linea);
        if (linea[0] == '\0') continue;
        char tmp[MAXLINE];
        strncpy(tmp, linea, sizeof(tmp)-1);
        tmp[sizeof(tmp)-1] = '\0';

        char *save = NULL;
        char *ap = strtok_r(tmp, ",", &save);
        char *h  = strtok_r(NULL, ",", &save);
        char *du = strtok_r(NULL, ",", &save);
        if (!ap || !h || !du) {
            fprintf(stderr, "[AGENTE] Línea CSV inválida: '%s'\n", linea);
            continue;
        }

        char out[MAXLINE];
        int m = snprintf(out, sizeof(out), "REQ,%s,%s,%s,%s\n", nombre, ap, h, du);
        if (write(fdw, out, (size_t)m) != m) {
            fprintf(stderr, "[AGENTE] Error enviando REQ: %s\n", strerror(errno));
            break;
        }
        struct timespec ts = { .tv_sec = 0, .tv_nsec = 50 * 1000000L };
        nanosleep(&ts, NULL);
    }
    fclose(fp);
    close(fdw);
    unlink(pipeResp);

    printf("Agente %s termina.\n", nombre);
    return EXIT_SUCCESS;
}
