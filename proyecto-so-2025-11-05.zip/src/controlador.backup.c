// controlador.c – Control de aforo + reprogramación automática
// Compila: gcc -Wall -Wextra -pthread -o bin/controlador src/controlador.c

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <time.h>

#define MAXLINE 512
#define HMIN 0
#define HMAX 23

typedef struct {
    int entran[24];        // solicitudes aceptadas en su hora
    int salen[24];         // no usamos salida real, pero dejamos la métrica
    int usados[24];        // ocupación por hora (aforo consumido)
    int reprog[24];        // cuántas reprogramadas hacia esta hora
} Contadores;

typedef struct {
    int hIni;
    int hFin;
    int segHora;   // segundos que dura 1 hora simulada
    int aforoMax;  // capacidad disponible por hora
    char pipePath[256];
} Params;

static int hora_actual_sim = 7;
static Contadores cnt;
static int negadas = 0;
static int aceptadas_en_su_hora = 0;
static int reprogramadas = 0;

static void uso(const char *p) {
    fprintf(stderr,
            "Uso: %s -i <iniHora> -f <finHora> -s <segHora> -t <aforoHora> -p <fifo>\n"
            "Ej.: %s -i 7 -f 19 -s 5 -t 30 -p /tmp/pipe1\n", p, p);
    exit(EXIT_FAILURE);
}

static int ensure_fifo_exists(const char *path) {
    struct stat st;
    if (stat(path, &st) == -1) {
        fprintf(stderr, "[CTRL] FIFO '%s' no existe (%s). Créalo con: mkfifo %s\n",
                path, strerror(errno), path);
        return -1;
    }
    if (!S_ISFIFO(st.st_mode)) {
        fprintf(stderr, "[CTRL] '%s' existe pero NO es FIFO.\n", path);
        return -1;
    }
    return 0;
}

static void rstrip(char *s) {
    size_t n = strlen(s);
    while (n > 0 && (s[n-1] == '\n' || s[n-1] == '\r')) s[--n] = '\0';
}

/* ---- Protocolo ----
 * HELLO,<agente>,<pipeResp>
 *   -> respuesta por <pipeResp>: HELLO_OK,<horaActual>
 *
 * REQ,<agente>,<apellido>,<hora>,<dur>
 *   Lógica:
 *   - Si usados[hora] < aforoMax -> aceptar en esa hora (en su hora)
 *   - Si no, buscar siguiente hora [hora+1 .. hFin] con cupo y reprogramar allí
 *   - Si no hay cupo en ninguna, negar
 *   * El controlador imprime el resultado; no es obligatorio responder al agente
 */
static void procesar_linea(const Params *par, const char *linea) {
    if (strncmp(linea, "HELLO,", 6) == 0) {
        char buf[MAXLINE];
        strncpy(buf, linea, sizeof(buf)-1);
        buf[sizeof(buf)-1] = '\0';
        char *save = NULL;
        (void)strtok_r(buf, ",", &save);      // HELLO
        char *ag = strtok_r(NULL, ",", &save);
        char *pipeResp = strtok_r(NULL, ",", &save);
        if (!ag || !pipeResp) return;

        int fdw = open(pipeResp, O_WRONLY);
        if (fdw == -1) {
            fprintf(stderr, "[WARN] No se pudo abrir pipeResp '%s' para HELLO_OK: %s\n",
                    pipeResp, strerror(errno));
            return;
        }
        char out[64];
        int n = snprintf(out, sizeof(out), "HELLO_OK,%d\n", hora_actual_sim);
        (void)write(fdw, out, (size_t)n);
        close(fdw);
        printf("[CTRL] Handshake de '%s' -> horaActual=%d (pipeResp=%s)\n",
               ag, hora_actual_sim, pipeResp);
        fflush(stdout);
        return;
    }

    if (strncmp(linea, "REQ,", 4) == 0) {
        char buf[MAXLINE];
        strncpy(buf, linea, sizeof(buf)-1);
        buf[sizeof(buf)-1] = '\0';

        char *save = NULL;
        (void)strtok_r(buf, ",", &save);      // REQ
        char *ag = strtok_r(NULL, ",", &save);
        char *ap = strtok_r(NULL, ",", &save);
        char *h  = strtok_r(NULL, ",", &save);
        char *du = strtok_r(NULL, ",", &save);
        if (!ag || !ap || !h || !du) return;

        int horaSolic = atoi(h);
        if (horaSolic < par->hIni || horaSolic > par->hFin) {
            // fuera de ventana -> negar
            ++negadas;
            printf("[CTRL] REQ de %s (%s) para hora %d -> FUERA_DE_RANGO -> NEGADA\n",
                   ag, ap, horaSolic);
            fflush(stdout);
            return;
        }

        // ¿hay cupo en la hora solicitada?
        if (cnt.usados[horaSolic] < par->aforoMax) {
            cnt.usados[horaSolic] += 1;
            cnt.entran[horaSolic] += 1;
            ++aceptadas_en_su_hora;
            printf("[CTRL] Recibido REQ de %s (%s) para hora %d, dur=%s -> ACEPTADA en su hora. usados[%d]=%d/%d\n",
                   ag, ap, horaSolic, du, horaSolic, cnt.usados[horaSolic], par->aforoMax);
            fflush(stdout);
            return;
        }

        // Buscar reprogramación: de la siguiente hora en adelante
        int hdest = -1;
        for (int hh = horaSolic + 1; hh <= par->hFin; ++hh) {
            if (cnt.usados[hh] < par->aforoMax) { hdest = hh; break; }
        }

        if (hdest != -1) {
            cnt.usados[hdest] += 1;
            cnt.reprog[hdest] += 1;
            ++reprogramadas;
            printf("[CTRL] REQ de %s (%s) para hora %d -> REPROGRAMADA a %d. usados[%d]=%d/%d\n",
                   ag, ap, horaSolic, hdest, hdest, cnt.usados[hdest], par->aforoMax);
            fflush(stdout);
            return;
        }

        // No hay cupo en ninguna -> negar
        ++negadas;
        printf("[CTRL] REQ de %s (%s) para hora %d -> SIN_CUPO -> NEGADA\n",
               ag, ap, horaSolic);
        fflush(stdout);
        return;
    }

    // otro tipo de línea: ignorar
}

int main(int argc, char **argv) {
    Params par = { .hIni = -1, .hFin = -1, .segHora = 5, .aforoMax = 30, .pipePath = {0} };

    int opt;
    while ((opt = getopt(argc, argv, "i:f:s:t:p:")) != -1) {
        switch (opt) {
            case 'i': par.hIni = atoi(optarg); break;
            case 'f': par.hFin = atoi(optarg); break;
            case 's': par.segHora = atoi(optarg); break;
            case 't': par.aforoMax = atoi(optarg); break;
            case 'p': strncpy(par.pipePath, optarg, sizeof(par.pipePath)-1); break;
            default: uso(argv[0]);
        }
    }
    if (par.hIni < 0 || par.hFin < 0 || par.hFin < par.hIni || par.pipePath[0] == '\0') {
        uso(argv[0]);
    }
    // Regla del curso
    if (par.hIni < 7 || par.hFin > 19) {
        fprintf(stderr, "[ERROR] El periodo debe estar entre 7 y 19.\n");
        return EXIT_FAILURE;
    }
    if (par.aforoMax < 0) par.aforoMax = 0;

    if (ensure_fifo_exists(par.pipePath) == -1) return EXIT_FAILURE;

    memset(&cnt, 0, sizeof(cnt));
    hora_actual_sim = par.hIni;

    printf("[CTRL] Servidor iniciado. Periodo [%d..%d], segHoras=%d, aforo=%d, pipe=%s\n",
           par.hIni, par.hFin, par.segHora, par.aforoMax, par.pipePath);
    fflush(stdout);

    // Abrimos FIFO en lectura no bloqueante
    int fdr = open(par.pipePath, O_RDONLY | O_NONBLOCK);
    if (fdr == -1) {
        fprintf(stderr, "[CTRL] No pude abrir FIFO '%s' para lectura: %s\n",
                par.pipePath, strerror(errno));
        return EXIT_FAILURE;
    }

    // Bucle del reloj
    for (int h = par.hIni; h <= par.hFin; ++h) {
        hora_actual_sim = h;

        printf("[RELOJ] Hora %2d: salen %d (<=) | entran %d (->) | usados %d/%d\n",
               h, cnt.salen[h], cnt.entran[h], cnt.usados[h], par.aforoMax);
        fflush(stdout);

        const int slice_ms = 50;
        int total_ms = par.segHora * 1000;
        char buffer[MAXLINE];

        while (total_ms > 0) {
            ssize_t n = read(fdr, buffer, sizeof(buffer)-1);
            if (n > 0) {
                buffer[n] = '\0';
                // procesar por líneas
                char *p = buffer;
                for (;;) {
                    char *nl = strchr(p, '\n');
                    if (!nl) { rstrip(p); if (*p) procesar_linea(&par, p); break; }
                    *nl = '\0';
                    rstrip(p);
                    if (*p) procesar_linea(&par, p);
                    p = nl + 1;
                    if (*p == '\0') break;
                }
            } else {
                struct timespec ts = { .tv_sec = 0, .tv_nsec = (long)slice_ms * 1000000L };
                nanosleep(&ts, NULL);
                total_ms -= slice_ms;
            }
        }
    }

    // Reporte
    printf("\n===== REPORTE FINAL =====\n");
    printf("Periodo:  [%d..%d]\n", par.hIni, par.hFin);
    printf("Aforo por hora: %d\n", par.aforoMax);
    printf("Solicitudes negadas: %d\n", negadas);
    printf("Solicitudes aceptadas en su hora: %d\n", aceptadas_en_su_hora);
    printf("Solicitudes reprogramadas: %d\n", reprogramadas);

    // Horas pico/valle calculadas por ocupación
    int maxu = 0;
    for (int h = par.hIni; h <= par.hFin; ++h) if (cnt.usados[h] > maxu) maxu = cnt.usados[h];

    printf("Horas pico (usados=%d):", maxu);
    for (int h = par.hIni; h <= par.hFin; ++h) if (cnt.usados[h] == maxu) printf(" %d", h);
    printf("\nHoras valle (usados=0):");
    for (int h = par.hIni; h <= par.hFin; ++h) if (cnt.usados[h] == 0) printf(" %d", h);
    printf("\n=========================\n");
    fflush(stdout);

    close(fdr);
    return EXIT_SUCCESS;
}

